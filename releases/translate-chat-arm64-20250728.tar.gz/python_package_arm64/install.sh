#!/bin/bash
# Translate Chat 安装脚本

echo "安装Translate Chat..."

# 安装系统依赖
if command -v apt-get &> /dev/null; then
    # Ubuntu/Debian
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip python3-venv portaudio19-dev
elif command -v yum &> /dev/null; then
    # CentOS/RHEL
    sudo yum install -y python3 python3-pip portaudio-devel
else
    echo "警告: 未知的包管理器，请手动安装Python3和PortAudio"
fi

# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
source venv/bin/activate

# 安装Python依赖
pip install -r requirements-desktop.txt

echo "安装完成！运行 ./run.sh 启动应用" 