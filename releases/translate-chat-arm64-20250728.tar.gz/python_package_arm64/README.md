# Translate Chat - ARM64 版本

## 安装说明

### 自动安装
```bash
./install.sh
```

### 手动安装
1. 安装Python3和PortAudio
2. 创建虚拟环境: `python3 -m venv venv`
3. 激活虚拟环境: `source venv/bin/activate`
4. 安装依赖: `pip install -r requirements-desktop.txt`

## 运行应用
```bash
./run.sh
```

## 系统要求
- Python 3.9-3.11
- PortAudio
- 网络连接（用于语音识别和翻译）

## 故障排除
如果遇到音频问题，请确保安装了PortAudio：
- Ubuntu/Debian: `sudo apt-get install portaudio19-dev`
- CentOS/RHEL: `sudo yum install portaudio-devel`

## 部署到树莓派
1. 将此目录复制到树莓派
2. 运行 `./install.sh` 安装依赖
3. 运行 `./run.sh` 启动应用 